import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BooktestdriveComponent } from './booktestdrive.component';

describe('BooktestdriveComponent', () => {
  let component: BooktestdriveComponent;
  let fixture: ComponentFixture<BooktestdriveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BooktestdriveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BooktestdriveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
