import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suv',
  templateUrl: './suv.component.html',
  styleUrls: ['./suv.component.css']
})
export class SuvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
