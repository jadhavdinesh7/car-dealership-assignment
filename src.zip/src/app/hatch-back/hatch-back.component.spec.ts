import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HatchBackComponent } from './hatch-back.component';

describe('HatchBackComponent', () => {
  let component: HatchBackComponent;
  let fixture: ComponentFixture<HatchBackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HatchBackComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HatchBackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
