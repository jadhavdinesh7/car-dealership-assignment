import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hatch-back',
  templateUrl: './hatch-back.component.html',
  styleUrls: ['./hatch-back.component.css']
})
export class HatchBackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
