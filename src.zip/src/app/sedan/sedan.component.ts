import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sedan',
  templateUrl: './sedan.component.html',
  styleUrls: ['./sedan.component.css']
})
export class SedanComponent implements OnInit {

  carList: { id: number, name: string, desc: string }[] = [
    { "id": 0, "name": "Car 1", "desc": "This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."  },
    { "id": 1, "name": "Car 2", "desc": "This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer." },
    { "id": 2, "name": "Car 3", "desc": "This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer." }
];
  constructor() { }

  ngOnInit(): void {
  }

}
