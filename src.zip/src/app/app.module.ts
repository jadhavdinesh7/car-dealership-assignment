import { APP_BASE_HREF } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BooktestdriveComponent } from './booktestdrive/booktestdrive.component';
import { ContactComponent } from './contact/contact.component';
import { HatchBackComponent } from './hatch-back/hatch-back.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { SedanComponent } from './sedan/sedan.component';
import { SuvComponent } from './suv/suv.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'products', component: ProductsComponent },
  {path: 'products/hatchback', component: HatchBackComponent},
  {path: 'products/sedan', component: SedanComponent},
  {path: 'products/suvs', component: SuvComponent}, 
  { path: 'about', component: AboutComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'bookatestdrive', component: BooktestdriveComponent },
  
];

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    SuvComponent,
    SedanComponent,
    HatchBackComponent,
    AboutComponent,
    ContactComponent,
    BooktestdriveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    FormsModule, 
    ReactiveFormsModule
  ],
  providers: [
    {provide: APP_BASE_HREF, useValue: '/'}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
